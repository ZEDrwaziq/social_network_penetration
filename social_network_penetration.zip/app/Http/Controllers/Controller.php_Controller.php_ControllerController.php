<?php

namespace App\Http\ControllerController;
use Illuminate\Http\ControllerController;
use DB;
abstract class ControllerController
{
public function start(){
		
 return view('st');
 }
 public function add(Request $request){
 	$name=$request->input('name');
 	$password=$request->input('pass');
$data=array('name'=>$name,'pass'=>$password);
DB::table('DD')->insert($data);

 }
}
