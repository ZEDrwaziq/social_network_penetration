<?php
use App\Http\Controllers\ControllerController;
use Illuminate\Support\Facades\Route;
Route::post('/add','App\Http\Controllers\ControllerController@add');
Route::get('/','App\Http\Controllers\ControllerController@start');